// app.js
require('dotenv').config();
const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const session = require('express-session');

const app = express();
const PORT = 3030;

// ===== Global Request Logger =====
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// ===== Static files =====
app.use(express.static(path.join(__dirname, 'html')));

// ===== Body parsers =====
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

/* ---------- Session ---------- */
app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev_secret_123",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 5 } // 5 ชม.
  })
);

/* ---------- MySQL Pool ---------- */
const DB_NAME = (process.env.DB_NAME || 'LandokmaiDB').trim();
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: 'utf8mb4'
});
console.log('✅ Using DB:', DB_NAME);

/* ---------- Helper ---------- */
function normalizeQuery(q = '') {
  return q.toString().trim();
}
function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "login_required" });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "login_required" });
  if (req.session.user.role !== "admin") return res.status(403).json({ error: "admin_only" });
  next();
}

/* =====================================================
   ✅  LOGIN จริง
===================================================== */
app.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  console.log(`Login submit => ${email}`);

  try {
    const [rows] = await pool.query(
      "SELECT id, email, password_hash, role FROM users WHERE email=? LIMIT 1",
      [email]
    );
    if (!rows.length) return res.sendFile(path.join(__dirname, 'html', 'Login.html'));

    const user = rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.sendFile(path.join(__dirname, 'html', 'Login.html'));

    req.session.user = {
      id: user.id,
      email: user.email,
      role: user.role
    };
    console.log("✅ Login success:", user.email, "role=", user.role);

    res.sendFile(path.join(__dirname, 'html', 'success.html'));
  } catch (e) {
    console.error("Login error", e);
    res.sendFile(path.join(__dirname, 'html', 'Login.html'));
  }
});

/* =====================================================
   ✅  API: เช็คสถานะ Login
===================================================== */
app.get("/api/me", (req, res) => {
  res.json(req.session.user || null);
});

/* =====================================================
   ✅  LOGOUT
===================================================== */
app.post('/api/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

/* =====================================================
   ✅  Admin API: เพิ่มสินค้า
===================================================== */
app.post("/api/admin/flowers", requireAdmin, async (req, res) => {
  const { name_th, name_en, price, image_url, description } = req.body;
  try {
    const [r] = await pool.query(
      `INSERT INTO flowers (name_th, name_en, price, image_url, description)
       VALUES (?, ?, ?, ?, ?)`,
      [name_th, name_en, price, image_url, description]
    );
    res.json({ ok: true, id: r.insertId });
  } catch (e) {
    console.error("Add flower error:", e);
    res.status(500).json({ error: "db_error" });
  }
});

/* =====================================================
   ✅ Admin API: ลบสินค้า
===================================================== */
app.delete("/api/admin/flowers/:id", requireAdmin, async (req, res) => {
  try {
    await pool.query("DELETE FROM flowers WHERE id=? LIMIT 1", [req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    console.error("Delete flower error:", e);
    res.status(500).json({ error: "db_error" });
  }
});

/* =====================================================
   ✅ Admin API: เขียน BLOG
===================================================== */
app.post("/api/admin/blog", requireAdmin, async (req, res) => {
  const { title, content, cover_image, tags } = req.body;
  try {
    const [r] = await pool.query(
      `INSERT INTO blog_posts (title, content, cover_image, tags, author_id)
       VALUES (?,?,?,?,?)`,
      [title, content, cover_image, tags, req.session.user.id]
    );
    res.json({ ok: true, id: r.insertId });
  } catch (e) {
    console.error("Blog error:", e);
    res.status(500).json({ error: "db_error" });
  }
});

/* =====================================================
   ✅ แก้แล้ว — API Search ภาษาไทยใช้งานได้
===================================================== */
app.get('/api/flowers', async (req, res) => {
  try {
    const keywordRaw = req.query.q || '';
    const keyword = normalizeQuery(keywordRaw);

    if (!keyword) return res.json([]);

    // ✅ แก้ตรงนี้ — เอา LOWER() ออกเพื่อให้ค้นหาภาษาไทยได้
    const sql = `
      SELECT id, name_th, name_en, price, image_url, description
      FROM flowers
      WHERE name_th LIKE ? OR name_en LIKE ?
      ORDER BY name_th ASC
      LIMIT 50
    `;

    const like = `%${keyword}%`;
    const [rows] = await pool.query(sql, [like, like]);

    return res.json(rows);
  } catch (err) {
    console.error('❌ /api/flowers error:', err);
    return res.status(500).json({ error: 'database error' });
  }
});

/* =====================================================
   ✅ หน้า Search
===================================================== */
app.get('/search', (req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'SearchResult.html'));
});

/* ---------- Routes เดิม ---------- */
app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'Homepage.html'));
});

app.get('/login', (_req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'Login.html'));
});

app.get('/success', (_req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'success.html'));
});

app.get('/register-admin', (_req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'RegisterAdmin.html'));
});

/* =====================================================
   ✅ Blog fetch
===================================================== */
app.get("/api/blog", async (req, res) => {
  try{
    const [rows] = await pool.query(`
      SELECT id, title, content, cover_image, tags, created_at
      FROM blog_posts
      ORDER BY created_at DESC
    `);
    res.json(rows);
  }catch(e){
    console.error("Blog fetch error:", e);
    res.status(500).json({error:"db_error"});
  }
});

/* ---------- 404 ---------- */
app.use((req, res) => {
  console.log('404:', req.url);
  res.status(404).sendFile(path.join(__dirname, 'html', 'not_Found.html'));
});

/* ---------- Start ---------- */
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
