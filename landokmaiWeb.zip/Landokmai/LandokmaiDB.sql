/* =========================
   DATABASE & DEFAULTS
   ========================= */
CREATE DATABASE IF NOT EXISTS LandokmaiDB
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE LandokmaiDB;

/* =========================
   TABLES
   ========================= */

/* ---- flowers (สินค้า) ----
   ถ้าไม่อยากล้างข้อมูลเดิม ให้ลบบรรทัด DROP ออก */
DROP TABLE IF EXISTS flowers;
CREATE TABLE IF NOT EXISTS flowers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name_th   VARCHAR(100) NOT NULL,
  name_en   VARCHAR(100),
  price     DECIMAL(10,2) NOT NULL DEFAULT 0,
  image_url VARCHAR(255),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_name_th (name_th),
  INDEX idx_name_en (name_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ---- users (ผู้ใช้ + สิทธิ์) ----
   สร้างถ้ายังไม่มี */
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* === ทำให้ schema ของ users ตรงตามที่โค้ดใช้ ===
   1) เพิ่มคอลัมน์ password_hash ถ้ายังไม่มี
   2) ถ้ามีคอลัมน์ legacy ชื่อ password ให้โอนย้ายค่า -> password_hash แล้วลบทิ้ง
*/
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) NOT NULL AFTER email;

-- โอนค่าเดิมจากคอลัมน์ password (ถ้ามี) มาไว้ใน password_hash
UPDATE users
   SET password_hash = COALESCE(password_hash, password)
 WHERE password_hash IS NULL
   AND (SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = 'users'
          AND COLUMN_NAME  = 'password') > 0;

-- ลบคอลัมน์ password เดิมออก (ถ้ามี)
ALTER TABLE users DROP COLUMN IF EXISTS password;

/* ---- blog_posts (บล็อก) ---- */
CREATE TABLE IF NOT EXISTS blog_posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(200) NOT NULL,
  content     MEDIUMTEXT,
  cover_image VARCHAR(255),
  tags        VARCHAR(255),
  author_id   INT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_blog_author
    FOREIGN KEY (author_id) REFERENCES users(id)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* =========================
   SEED DATA
   ========================= */

/* ---- สินค้าเริ่มต้น ---- */
INSERT INTO flowers (name_th, name_en, price, image_url, description) VALUES
('กุหลาบ1', 'Red Rose', 450.00, 'https://static.wixstatic.com/media/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg/v1/fill/w_245,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg', 'สื่อถึงความรัก ความโรแมนติก เหมาะกับโอกาสพิเศษ'),
('กุหลาบ2', 'Red Rose', 550.00, 'https://static.wixstatic.com/media/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg/v1/fill/w_245,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg', 'สื่อถึงความรัก ความโรแมนติก เหมาะกับโอกาสพิเศษ'),
('กุหลาบ3', 'Red Rose', 650.00, 'https://static.wixstatic.com/media/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg/v1/fill/w_245,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg', 'สื่อถึงความรัก ความโรแมนติก เหมาะกับโอกาสพิเศษ'),
('กุหลาบ4', 'Red Rose', 450.00, 'https://static.wixstatic.com/media/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg/v1/fill/w_245,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg', 'สื่อถึงความรัก ความโรแมนติก เหมาะกับโอกาสพิเศษ'),
('กุหลาบ5', 'Red Rose', 550.00, 'https://static.wixstatic.com/media/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg/v1/fill/w_245,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg', 'สื่อถึงความรัก ความโรแมนติก เหมาะกับโอกาสพิเศษ'),
('กุหลาบ6', 'Red Rose', 650.00, 'https://static.wixstatic.com/media/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg/v1/fill/w_245,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_a77a1b923b1049029fd0f6efed0ade0d~mv2.jpg', 'สื่อถึงความรัก ความโรแมนติก เหมาะกับโอกาสพิเศษ'),

('ทิวลิป1', 'Pink Tulip', 390.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ให้ความหมายถึงความห่วงใย ความเอ็นดู'),
('ทิวลิป2', 'Pink Tulip', 390.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ให้ความหมายถึงความห่วงใย ความเอ็นดู'),
('ทิวลิป3', 'Pink Tulip', 390.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ให้ความหมายถึงความห่วงใย ความเอ็นดู'),
('ทิวลิป4', 'Pink Tulip', 390.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ให้ความหมายถึงความห่วงใย ความเอ็นดู'),
('ทิวลิป5', 'Pink Tulip', 390.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ให้ความหมายถึงความห่วงใย ความเอ็นดู'),
('ทิวลิป6', 'Pink Tulip', 390.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ให้ความหมายถึงความห่วงใย ความเอ็นดู'),

('ทานตะวัน1', 'Sunflower', 320.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'สื่อถึงความสดใส ให้กำลังใจ'),
('ทานตะวัน2', 'Sunflower', 320.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'สื่อถึงความสดใส ให้กำลังใจ'),
('ทานตะวัน3', 'Sunflower', 320.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'สื่อถึงความสดใส ให้กำลังใจ'),
('ทานตะวัน4', 'Sunflower', 320.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'สื่อถึงความสดใส ให้กำลังใจ'),
('ทานตะวัน5', 'Sunflower', 320.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'สื่อถึงความสดใส ให้กำลังใจ'),
('ทานตะวัน6', 'Sunflower', 320.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'สื่อถึงความสดใส ให้กำลังใจ'),

('กล้วยไม้1', 'White Orchid', 520.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ดูสุภาพ เรียบหรู เหมาะให้ผู้ใหญ่'),
('กล้วยไม้2', 'White Orchid', 520.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ดูสุภาพ เรียบหรู เหมาะให้ผู้ใหญ่'),
('กล้วยไม้3', 'White Orchid', 520.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ดูสุภาพ เรียบหรู เหมาะให้ผู้ใหญ่'),
('กล้วยไม้4', 'White Orchid', 520.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ดูสุภาพ เรียบหรู เหมาะให้ผู้ใหญ่'),
('กล้วยไม้5', 'White Orchid', 520.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ดูสุภาพ เรียบหรู เหมาะให้ผู้ใหญ่'),
('กล้วยไม้6', 'White Orchid', 520.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'ดูสุภาพ เรียบหรู เหมาะให้ผู้ใหญ่'),

('ลิลลี่1', 'White Lily', 480.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'หมายถึงความบริสุทธิ์ ความตั้งใจดี'),
('ลิลลี่2', 'White Lily', 480.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'หมายถึงความบริสุทธิ์ ความตั้งใจดี'),
('ลิลลี่3', 'White Lily', 480.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'หมายถึงความบริสุทธิ์ ความตั้งใจดี'),
('ลิลลี่4', 'White Lily', 480.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'หมายถึงความบริสุทธิ์ ความตั้งใจดี'),
('ลิลลี่5', 'White Lily', 480.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'หมายถึงความบริสุทธิ์ ความตั้งใจดี'),
('ลิลลี่6', 'White Lily', 480.00, 'https://static.wixstatic.com/media/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg/v1/fill/w_275,h_275,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/78aa83_4aeaca6cc73449e7a144d1d3b2c11c39~mv2.jpg', 'หมายถึงความบริสุทธิ์ ความตั้งใจดี');

/* ---- สร้าง admin เริ่มต้น (email & hash ของ admin123) ----
   ถ้ามีอยู่แล้วจะไม่แทรกซ้ำ */
INSERT INTO users (email, password_hash, role)
SELECT 'admin@example.com', '$2b$10$2rNQk8EPwW2s3h9bqvT0HusWvQ8o8L5Kxgq7YJ3o0L0teQJx5kX9K', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='admin@example.com');

/* =========================
   CHECK
   ========================= */
SHOW TABLES;
SELECT COUNT(*) AS flower_count FROM flowers;
SELECT id,email,role FROM users;
